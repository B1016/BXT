# bxt

A simple video editor for Android, tuned for low-end devices.

- Import several videos (read straight from storage; never loaded fully into memory).
- Trim, split at the playhead, reorder, delete, join clips.
- Per-clip speed (0.5x to 3x) and mute; add a music track (optionally keeping original sound).
- Export 480p / 720p / 1080p. Fast 480p is the recommended preset on low-RAM devices.
- Saves to Movies/bxt.

Build: see the GitHub Actions workflow (Gradle 8.11.1, Java 17).
