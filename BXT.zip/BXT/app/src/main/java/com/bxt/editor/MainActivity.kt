package com.bxt.editor

import android.app.Activity
import android.app.ActivityManager
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.SurfaceView
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.media3.common.C
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.SpeedProvider
import androidx.media3.effect.Presentation
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import java.io.File
import java.util.Collections
import kotlin.math.max
import kotlin.math.min

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
private const val REQ_VIDEO = 1
private const val REQ_MUSIC = 2
private const val MIN_CLIP_MS = 300L
private const val ACCENT = 0xFF0A84FF.toInt()
private const val CHIP = 0xFF26262F.toInt()

/** Plays one fixed speed for a whole clip. */
private class ConstantSpeed(private val speed: Float) : SpeedProvider {
    override fun getSpeed(presentationTimeUs: Long): Float = speed
    override fun getNextSpeedChangeTimeUs(timeUs: Long): Long = C.TIME_UNSET
}

class MainActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private val clips = ArrayList<Clip>()
    private var selected = -1
    private var nextId = 1L
    private var musicUri: Uri? = null
    private var musicName = ""
    private var keepOriginal = false

    private var player: ExoPlayer? = null
    private var transformer: Transformer? = null
    private var exportFile: File? = null
    private var exporting = false
    private var updatingUi = false
    private var seeking = false

    private lateinit var surfaceBox: FrameLayout
    private lateinit var surface: SurfaceView
    private lateinit var emptyHint: TextView
    private lateinit var playBtn: TextView
    private lateinit var seek: SeekBar
    private lateinit var timeText: TextView
    private lateinit var totalText: TextView
    private lateinit var timeline: LinearLayout
    private lateinit var controls: LinearLayout
    private lateinit var trimLabel: TextView
    private lateinit var trimStart: SeekBar
    private lateinit var trimEnd: SeekBar
    private lateinit var muteChip: TextView
    private val speedChips = ArrayList<Pair<Float, TextView>>()
    private lateinit var musicLabel: TextView
    private lateinit var keepChip: TextView
    private lateinit var removeMusicChip: TextView
    private lateinit var overlay: FrameLayout
    private lateinit var overlayText: TextView
    private lateinit var overlayBar: ProgressBar

    private fun dp(v: Float): Float = v * resources.displayMetrics.density
    private fun dpi(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    // ───────────────────────── lifecycle ─────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        createPlayer()
        refreshUi()
    }

    override fun onResume() {
        super.onResume()
        handler.post(ticker)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        player?.pause()
        super.onPause()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        transformer?.cancel()
        player?.release()
        player = null
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        when (requestCode) {
            REQ_VIDEO -> {
                val cd = data.clipData
                if (cd != null) {
                    for (i in 0 until cd.itemCount) importVideo(cd.getItemAt(i).uri)
                } else {
                    data.data?.let { importVideo(it) }
                }
            }
            REQ_MUSIC -> {
                val u = data.data ?: return
                try {
                    contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (e: Exception) {
                }
                musicUri = u
                musicName = displayName(u)
                keepOriginal = false
                refreshUi()
            }
        }
    }

    // ───────────────────────── UI ─────────────────────────

    private fun chip(text: String, onClick: () -> Unit): TextView = TextView(this).apply {
        this.text = text
        setTextColor(Color.WHITE)
        textSize = 14f
        gravity = Gravity.CENTER
        setPadding(dpi(14), dpi(9), dpi(14), dpi(9))
        background = GradientDrawable().apply {
            setColor(CHIP)
            cornerRadius = dp(10f)
        }
        setOnClickListener { onClick() }
    }

    private fun paintChip(v: TextView, on: Boolean) {
        (v.background as GradientDrawable).setColor(if (on) ACCENT else CHIP)
    }

    private fun label(text: String): TextView = TextView(this).apply {
        this.text = text
        setTextColor(0xFFB0B0BC.toInt())
        textSize = 13f
        setPadding(0, dpi(14), 0, dpi(6))
    }

    private fun row(vararg views: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        for (v in views) {
            addView(v, LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dpi(8) })
        }
    }

    private fun buildUi() {
        val frame = FrameLayout(this)
        ViewCompat.setOnApplyWindowInsetsListener(frame) { v, insets ->
            val s = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(s.left, s.top, s.right, s.bottom)
            insets
        }
        val column = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        frame.addView(column, FrameLayout.LayoutParams(MATCH, MATCH))

        // top bar
        val title = TextView(this).apply {
            text = "bxt"
            setTextColor(Color.WHITE)
            textSize = 24f
            typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
        }
        val addVideo = chip("+ Video") { pickVideo() }
        val addMusic = chip("+ Music") { pickMusic() }
        val export = chip("Export") { chooseQuality() }.also { paintChip(it, true) }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dpi(16), dpi(8), dpi(12), dpi(8))
            addView(title, LinearLayout.LayoutParams(0, WRAP, 1f))
            addView(addVideo, LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dpi(8) })
            addView(addMusic, LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dpi(8) })
            addView(export, LinearLayout.LayoutParams(WRAP, WRAP))
        }
        column.addView(top, LinearLayout.LayoutParams(MATCH, WRAP))

        // preview
        surfaceBox = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        surface = SurfaceView(this)
        surfaceBox.addView(surface, FrameLayout.LayoutParams(MATCH, MATCH, Gravity.CENTER))
        emptyHint = TextView(this).apply {
            text = "Tap + Video to add clips"
            setTextColor(0xFF8A8A96.toInt())
            textSize = 15f
        }
        surfaceBox.addView(emptyHint, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
        val boxH = (resources.displayMetrics.heightPixels * 0.30f).toInt()
        column.addView(surfaceBox, LinearLayout.LayoutParams(MATCH, boxH))

        // play bar
        playBtn = chip("Play") { togglePlay() }
        seek = SeekBar(this).apply { max = 1000 }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                val c = clips.getOrNull(selected) ?: return
                player?.seekTo(p.toLong() * max(1L, c.endMs - c.startMs) / 1000)
            }

            override fun onStartTrackingTouch(sb: SeekBar) {
                seeking = true
            }

            override fun onStopTrackingTouch(sb: SeekBar) {
                seeking = false
            }
        })
        timeText = TextView(this).apply {
            setTextColor(0xFFB0B0BC.toInt())
            textSize = 12f
            text = "0:00.0 / 0:00.0"
        }
        val playBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dpi(12), dpi(8), dpi(12), dpi(4))
            addView(playBtn, LinearLayout.LayoutParams(WRAP, WRAP))
            addView(seek, LinearLayout.LayoutParams(0, WRAP, 1f))
            addView(timeText, LinearLayout.LayoutParams(WRAP, WRAP))
        }
        column.addView(playBar, LinearLayout.LayoutParams(MATCH, WRAP))

        // scrolling editor area
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dpi(16), 0, dpi(16), dpi(24))
        }
        totalText = TextView(this).apply {
            setTextColor(0xFFB0B0BC.toInt())
            textSize = 13f
            setPadding(0, dpi(6), 0, dpi(6))
        }
        body.addView(totalText)
        timeline = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val hs = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(timeline, FrameLayout.LayoutParams(WRAP, WRAP))
        }
        body.addView(hs, LinearLayout.LayoutParams(MATCH, WRAP))

        controls = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        trimLabel = label("Trim")
        trimStart = trimBar(true)
        trimEnd = trimBar(false)
        controls.addView(trimLabel)
        controls.addView(trimStart, LinearLayout.LayoutParams(MATCH, WRAP))
        controls.addView(trimEnd, LinearLayout.LayoutParams(MATCH, WRAP))
        controls.addView(label("Edit"))
        controls.addView(
            row(
                chip("Split here") { splitClip() },
                chip("Delete") { deleteClip() },
                chip("Move left") { moveClip(-1) },
                chip("Move right") { moveClip(1) }
            )
        )
        controls.addView(label("Speed"))
        val speedRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (s in floatArrayOf(0.5f, 1f, 1.5f, 2f, 3f)) {
            val ch = chip(speedText(s)) { setSpeed(s) }
            speedChips.add(s to ch)
            speedRow.addView(ch, LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dpi(8) })
        }
        controls.addView(speedRow)
        muteChip = chip("Mute clip") { toggleMute() }
        controls.addView(label("Sound"))
        controls.addView(row(muteChip))
        body.addView(controls, LinearLayout.LayoutParams(MATCH, WRAP))

        body.addView(label("Music"))
        musicLabel = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 14f
        }
        keepChip = chip("Keep original sound") {
            keepOriginal = !keepOriginal
            refreshUi()
        }
        removeMusicChip = chip("Remove music") {
            musicUri = null
            musicName = ""
            refreshUi()
        }
        body.addView(musicLabel)
        body.addView(
            LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dpi(8), 0, 0)
                addView(keepChip, LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dpi(8) })
                addView(removeMusicChip, LinearLayout.LayoutParams(WRAP, WRAP))
            }
        )

        val scroll = ScrollView(this).apply { addView(body, FrameLayout.LayoutParams(MATCH, WRAP)) }
        column.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))

        // export overlay (blocks touches while exporting)
        overlay = FrameLayout(this).apply {
            setBackgroundColor(0xEE000000.toInt())
            isClickable = true
            visibility = View.GONE
        }
        overlayText = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 16f
            gravity = Gravity.CENTER
        }
        overlayBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        val cancel = chip("Cancel") { cancelExport() }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dpi(32), 0, dpi(32), 0)
            addView(overlayText, LinearLayout.LayoutParams(MATCH, WRAP))
            addView(overlayBar, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dpi(16); bottomMargin = dpi(20) })
            addView(cancel, LinearLayout.LayoutParams(WRAP, WRAP))
        }
        overlay.addView(box, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.CENTER))
        frame.addView(overlay, FrameLayout.LayoutParams(MATCH, MATCH))

        setContentView(frame)
    }

    private fun trimBar(isStart: Boolean): SeekBar = SeekBar(this).apply {
        max = 1000
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                if (!fromUser || updatingUi) return
                val c = clips.getOrNull(selected) ?: return
                val ms = p.toLong() * c.durationMs / 1000
                if (isStart) {
                    c.startMs = minOf(ms, c.endMs - MIN_CLIP_MS).coerceAtLeast(0L)
                } else {
                    c.endMs = maxOf(ms, c.startMs + MIN_CLIP_MS).coerceAtMost(c.durationMs)
                }
                updateTrimLabel(c)
            }

            override fun onStartTrackingTouch(sb: SeekBar) {}

            override fun onStopTrackingTouch(sb: SeekBar) {
                loadPreview()
                refreshUi()
            }
        })
    }

    private fun speedText(s: Float): String = if (s == s.toInt().toFloat()) "${s.toInt()}x" else "${s}x"

    private fun updateTrimLabel(c: Clip) {
        trimLabel.text = "Trim  ${fmt(c.startMs)} to ${fmt(c.endMs)}  (${fmt(c.endMs - c.startMs)})"
    }

    private fun refreshUi() {
        refreshTimeline()
        refreshControls()
        val total = clips.sumOf { it.outMs }
        totalText.text = if (clips.isEmpty()) "No clips yet" else "${clips.size} clip(s), total ${fmt(total)}"
        emptyHint.visibility = if (clips.isEmpty()) View.VISIBLE else View.GONE
        musicLabel.text = if (musicUri == null) "No music added" else musicName
        keepChip.visibility = if (musicUri == null) View.GONE else View.VISIBLE
        removeMusicChip.visibility = if (musicUri == null) View.GONE else View.VISIBLE
        keepChip.text = if (keepOriginal) "Original sound: on" else "Original sound: off"
        paintChip(keepChip, keepOriginal)
    }

    private fun refreshTimeline() {
        timeline.removeAllViews()
        for ((i, c) in clips.withIndex()) {
            val isSel = i == selected
            val cell = FrameLayout(this).apply {
                background = GradientDrawable().apply {
                    setColor(0xFF1C1C24.toInt())
                    cornerRadius = dp(8f)
                    setStroke(dpi(if (isSel) 3 else 1), if (isSel) ACCENT else 0xFF33333D.toInt())
                }
                setPadding(dpi(3), dpi(3), dpi(3), dpi(3))
                setOnClickListener { select(i) }
            }
            val iv = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setImageBitmap(c.thumb)
            }
            cell.addView(iv, FrameLayout.LayoutParams(MATCH, MATCH))
            val tag = StringBuilder(fmt(c.outMs))
            if (c.speed != 1f) tag.append("  ").append(speedText(c.speed))
            if (c.muted) tag.append("  muted")
            val tv = TextView(this).apply {
                text = tag.toString()
                setTextColor(Color.WHITE)
                textSize = 11f
                setShadowLayer(4f, 0f, 1f, Color.BLACK)
                setPadding(dpi(4), 0, 0, dpi(2))
            }
            cell.addView(tv, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.START))
            timeline.addView(cell, LinearLayout.LayoutParams(dpi(112), dpi(72)).apply { rightMargin = dpi(8) })
        }
    }

    private fun refreshControls() {
        val c = clips.getOrNull(selected)
        controls.visibility = if (c == null) View.GONE else View.VISIBLE
        if (c == null) return
        updatingUi = true
        trimStart.progress = (c.startMs * 1000 / c.durationMs).toInt()
        trimEnd.progress = (c.endMs * 1000 / c.durationMs).toInt()
        updatingUi = false
        updateTrimLabel(c)
        for ((s, ch) in speedChips) paintChip(ch, s == c.speed)
        muteChip.text = if (c.muted) "Clip is muted" else "Mute clip"
        paintChip(muteChip, c.muted)
    }

    // ───────────────────────── editing ─────────────────────────

    private fun select(i: Int) {
        selected = i
        loadPreview()
        refreshUi()
    }

    private fun splitClip() {
        val c = clips.getOrNull(selected) ?: return
        val p = player ?: return
        val at = c.startMs + p.currentPosition
        if (at <= c.startMs + MIN_CLIP_MS || at >= c.endMs - MIN_CLIP_MS) {
            Toast.makeText(this, "Move the playhead inside the clip first", Toast.LENGTH_SHORT).show()
            return
        }
        val a = c.copyClip(nextId++).also { it.endMs = at }
        val b = c.copyClip(nextId++).also { it.startMs = at }
        clips[selected] = a
        clips.add(selected + 1, b)
        select(selected)
    }

    private fun deleteClip() {
        if (selected !in clips.indices) return
        clips.removeAt(selected)
        selected = min(selected, clips.size - 1)
        loadPreview()
        refreshUi()
    }

    private fun moveClip(dir: Int) {
        val j = selected + dir
        if (selected !in clips.indices || j !in clips.indices) return
        Collections.swap(clips, selected, j)
        selected = j
        refreshUi()
    }

    private fun setSpeed(s: Float) {
        val c = clips.getOrNull(selected) ?: return
        c.speed = s
        player?.setPlaybackSpeed(s)
        refreshUi()
    }

    private fun toggleMute() {
        val c = clips.getOrNull(selected) ?: return
        c.muted = !c.muted
        player?.volume = if (c.muted) 0f else 1f
        refreshUi()
    }

    // ───────────────────────── importing ─────────────────────────

    private fun pickVideo() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "video/*"
            addCategory(Intent.CATEGORY_OPENABLE)
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(i, REQ_VIDEO)
    }

    private fun pickMusic() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "audio/*"
            addCategory(Intent.CATEGORY_OPENABLE)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(i, REQ_MUSIC)
    }

    private fun displayName(u: Uri): String {
        try {
            contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) return it.getString(0) ?: "Music"
            }
        } catch (e: Exception) {
        }
        return "Music"
    }

    /** Reads only the header of the video (never the whole file), so huge files are fine. */
    private fun importVideo(uri: Uri) {
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: Exception) {
        }
        Thread {
            val r = MediaMetadataRetriever()
            var dur = 0L
            var w = 0
            var h = 0
            var thumb: Bitmap? = null
            try {
                r.setDataSource(this, uri)
                dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
                h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
                val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
                if (rot == 90 || rot == 270) {
                    val t = w
                    w = h
                    h = t
                }
                thumb = grabThumb(r, w, h)
            } catch (e: Exception) {
                dur = 0L
            } finally {
                try {
                    r.release()
                } catch (e: Exception) {
                }
            }
            runOnUiThread {
                if (dur <= 0L || w <= 0 || h <= 0) {
                    Toast.makeText(this, "Can't read that video", Toast.LENGTH_SHORT).show()
                } else {
                    clips.add(Clip(nextId++, uri, dur, w, h, 0L, dur, thumb = thumb))
                    select(clips.size - 1)
                }
            }
        }.start()
    }

    private fun grabThumb(r: MediaMetadataRetriever, w: Int, h: Int): Bitmap? {
        if (w <= 0 || h <= 0) return null
        val tw = 192
        val th = max(1, 192 * h / w)
        return try {
            if (Build.VERSION.SDK_INT >= 27) {
                r.getScaledFrameAtTime(0L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, tw, th)
            } else {
                r.getFrameAtTime(0L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    ?.let { Bitmap.createScaledBitmap(it, tw, th, true) }
            }
        } catch (e: Exception) {
            null
        }
    }

    // ───────────────────────── preview player ─────────────────────────

    private fun createPlayer() {
        // small buffers keep memory use low on weak devices
        val load = DefaultLoadControl.Builder().setBufferDurationsMs(1500, 4000, 500, 1000).build()
        val p = ExoPlayer.Builder(this).setLoadControl(load).build()
        p.setVideoSurfaceView(surface)
        p.addListener(object : Player.Listener {
            override fun onVideoSizeChanged(videoSize: VideoSize) {
                fitSurface(videoSize)
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                playBtn.text = if (isPlaying) "Pause" else "Play"
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) {
                    p.pause()
                    p.seekTo(0L)
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                Toast.makeText(this@MainActivity, "Can't play that clip", Toast.LENGTH_SHORT).show()
            }
        })
        player = p
        loadPreview()
    }

    private fun loadPreview() {
        val p = player ?: return
        val c = clips.getOrNull(selected)
        if (c == null) {
            p.stop()
            p.clearMediaItems()
            return
        }
        val item = MediaItem.Builder()
            .setUri(c.uri)
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(c.startMs)
                    .setEndPositionMs(c.endMs)
                    .build()
            )
            .build()
        p.setMediaItem(item)
        p.setPlaybackSpeed(c.speed)
        p.volume = if (c.muted) 0f else 1f
        p.prepare()
        p.playWhenReady = false
    }

    private fun togglePlay() {
        val p = player ?: return
        if (clips.isEmpty()) return
        if (p.isPlaying) {
            p.pause()
        } else {
            if (p.playbackState == Player.STATE_ENDED) p.seekTo(0L)
            p.play()
        }
    }

    private fun fitSurface(v: VideoSize) {
        if (v.width == 0 || v.height == 0) return
        val bw = surfaceBox.width
        val bh = surfaceBox.height
        if (bw == 0 || bh == 0) {
            surfaceBox.post { fitSurface(v) }
            return
        }
        val ar = v.width.toFloat() * v.pixelWidthHeightRatio / v.height
        var w = bw
        var h = (bw / ar).toInt()
        if (h > bh) {
            h = bh
            w = (bh * ar).toInt()
        }
        val lp = surface.layoutParams as FrameLayout.LayoutParams
        lp.width = w
        lp.height = h
        lp.gravity = Gravity.CENTER
        surface.layoutParams = lp
    }

    private val ticker = object : Runnable {
        override fun run() {
            val c = clips.getOrNull(selected)
            val p = player
            if (c != null && p != null) {
                val len = max(1L, c.endMs - c.startMs)
                val pos = p.currentPosition.coerceIn(0L, len)
                if (!seeking) seek.progress = (pos * 1000 / len).toInt()
                timeText.text = "${fmt(pos)} / ${fmt(len)}"
            }
            handler.postDelayed(this, 250)
        }
    }

    // ───────────────────────── export ─────────────────────────

    private fun chooseQuality() {
        if (exporting) return
        if (clips.isEmpty()) {
            Toast.makeText(this, "Add a video first", Toast.LENGTH_SHORT).show()
            return
        }
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val low = am.isLowRamDevice || am.memoryClass <= 128
        val list = listOf(
            Quality("Fast 480p" + if (low) "  (recommended)" else "", 480, 1_800_000, 24),
            Quality("Balanced 720p" + if (!low) "  (recommended)" else "", 720, 4_000_000, 30),
            Quality("High 1080p", 1080, 8_000_000, 30)
        )
        AlertDialog.Builder(this)
            .setTitle("Export quality")
            .setItems(Array(list.size) { list[it].label }) { _, which -> startExport(list[which]) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun buildComposition(q: Quality): Composition {
        val first = clips[0]
        var outH = min(q.height, first.height)
        outH -= outH % 2
        if (outH < 2) outH = 2
        var outW = (first.width.toLong() * outH / first.height).toInt()
        outW -= outW % 2
        if (outW < 2) outW = 2

        val music = musicUri
        val dropOriginal = music != null && !keepOriginal
        val items = ArrayList<EditedMediaItem>()
        for (c in clips) {
            val mi = MediaItem.Builder()
                .setUri(c.uri)
                .setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(c.startMs)
                        .setEndPositionMs(c.endMs)
                        .build()
                )
                .build()
            val videoEffects = ArrayList<Effect>()
            videoEffects.add(Presentation.createForWidthAndHeight(outW, outH, Presentation.LAYOUT_SCALE_TO_FIT))
            val b = EditedMediaItem.Builder(mi)
                .setDurationUs(c.durationMs * 1000L)
                .setEffects(Effects(ArrayList<AudioProcessor>(), videoEffects))
                .setFrameRate(q.fps)
            if (c.speed != 1f) b.setSpeed(ConstantSpeed(c.speed))
            if (c.muted || dropOriginal) b.setRemoveAudio(true)
            items.add(b.build())
        }
        val videoSeq = if (dropOriginal) {
            EditedMediaItemSequence.withVideoFrom(items)
        } else {
            EditedMediaItemSequence.withAudioAndVideoFrom(items)
        }
        val seqs = ArrayList<EditedMediaItemSequence>()
        seqs.add(videoSeq)
        if (music != null) {
            val total = clips.sumOf { it.outMs }
            val mm = MediaItem.Builder()
                .setUri(music)
                .setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(0L)
                        .setEndPositionMs(total)
                        .build()
                )
                .build()
            val mi = EditedMediaItem.Builder(mm).setRemoveVideo(true).build()
            seqs.add(EditedMediaItemSequence.withAudioFrom(listOf(mi)))
        }
        return Composition.Builder(seqs).build()
    }

    private fun startExport(q: Quality) {
        // large files are streamed, but the finished video needs room in app storage first
        val totalSec = clips.sumOf { it.outMs } / 1000L
        val needBytes = (q.bitrate + 160_000L) * max(1L, totalSec) / 8L
        if (cacheDir.usableSpace < needBytes + needBytes / 4) {
            Toast.makeText(this, "Not enough free space for this export", Toast.LENGTH_LONG).show()
            return
        }
        cacheDir.listFiles()?.forEach { if (it.name.startsWith("bxt_")) it.delete() }
        val out = File(cacheDir, "bxt_${System.currentTimeMillis()}.mp4")
        exportFile = out

        val composition = try {
            buildComposition(q)
        } catch (e: Exception) {
            Toast.makeText(this, "Can't build the video: ${e.message}", Toast.LENGTH_LONG).show()
            return
        }

        // free the preview player's memory while exporting
        player?.release()
        player = null
        exporting = true
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        overlay.visibility = View.VISIBLE
        overlayBar.progress = 0
        overlayText.text = "Exporting... 0%\nKeep this screen open"

        val encoder = DefaultEncoderFactory.Builder(this)
            .setRequestedVideoEncoderSettings(VideoEncoderSettings.Builder().setBitrate(q.bitrate).build())
            .build()
        val t = Transformer.Builder(this)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .setEncoderFactory(encoder)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    finishExport(null)
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    finishExport(exportException.message ?: "Export failed")
                }
            })
            .build()
        transformer = t
        try {
            t.start(composition, out.absolutePath)
            handler.post(progressTicker)
        } catch (e: Exception) {
            finishExport(e.message ?: "Export failed")
        }
    }

    private val progressTicker = object : Runnable {
        override fun run() {
            val t = transformer
            if (!exporting || t == null) return
            val holder = ProgressHolder()
            val state = t.getProgress(holder)
            if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                overlayBar.progress = holder.progress
                overlayText.text = "Exporting... ${holder.progress}%\nKeep this screen open"
            }
            handler.postDelayed(this, 500)
        }
    }

    private fun cancelExport() {
        transformer?.cancel()
        finishExport("Export cancelled")
    }

    private fun finishExport(error: String?) {
        if (!exporting) return
        exporting = false
        handler.removeCallbacks(progressTicker)
        transformer = null
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val file = exportFile
        if (error != null || file == null) {
            overlay.visibility = View.GONE
            file?.delete()
            Toast.makeText(this, error ?: "Export failed", Toast.LENGTH_LONG).show()
            createPlayer()
            return
        }
        overlayText.text = "Saving to your gallery..."
        overlayBar.progress = 100
        Thread {
            val saved = saveToGallery(file)
            file.delete()
            runOnUiThread {
                overlay.visibility = View.GONE
                Toast.makeText(
                    this,
                    if (saved != null) "Saved: $saved" else "Couldn't save the video",
                    Toast.LENGTH_LONG
                ).show()
                createPlayer()
            }
        }.start()
    }

    /** Copies the finished file in small chunks, so even very large videos need little memory. */
    private fun saveToGallery(file: File): String? {
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                val v = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, file.name)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/bxt")
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }
                val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v) ?: return null
                contentResolver.openOutputStream(uri)?.use { os ->
                    file.inputStream().use { it.copyTo(os, 1 shl 16) }
                } ?: return null
                v.clear()
                v.put(MediaStore.Video.Media.IS_PENDING, 0)
                contentResolver.update(uri, v, null, null)
                "Movies/bxt/${file.name}"
            } else {
                val dir = getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: return null
                dir.mkdirs()
                val dest = File(dir, file.name)
                file.inputStream().use { i -> dest.outputStream().use { o -> i.copyTo(o, 1 shl 16) } }
                dest.absolutePath
            }
        } catch (e: Exception) {
            null
        }
    }
}
