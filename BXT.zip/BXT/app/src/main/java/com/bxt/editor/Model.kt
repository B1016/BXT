package com.bxt.editor

import android.graphics.Bitmap
import android.net.Uri

/** One clip on the timeline: a source video plus its trim, speed and mute settings. */
class Clip(
    val id: Long,
    val uri: Uri,
    val durationMs: Long,
    val width: Int,
    val height: Int,
    var startMs: Long,
    var endMs: Long,
    var speed: Float = 1f,
    var muted: Boolean = false,
    val thumb: Bitmap? = null
) {
    /** Length of this clip in the finished video (after trim and speed). */
    val outMs: Long get() = ((endMs - startMs) / speed).toLong()

    fun copyClip(newId: Long): Clip = Clip(newId, uri, durationMs, width, height, startMs, endMs, speed, muted, thumb)
}

/** An export preset. Lower presets are far lighter on weak phones. */
class Quality(val label: String, val height: Int, val bitrate: Int, val fps: Int)

fun fmt(ms: Long): String {
    val m = max0(ms)
    val s = m / 1000
    val t = (m % 1000) / 100
    return "%d:%02d.%d".format(s / 60, s % 60, t)
}

fun max0(v: Long): Long = if (v < 0L) 0L else v
